package com.org;

import com.day.three.Car;
import com.day.three.IDrivable;

public class Audi  extends Car {

	public static void main(String[] args) {
		System.out.println(IDrivable.pi);
	}

	@Override
	public void drive() {
		
	}

	@Override
	public void stop() {
		
	}

}
