package com.org;

public class User {
	
	public static void main(String[] args) throws InterruptedException {
		
		System.out.println(Thread.currentThread());
		
		Bulb bulbSwith = new Bulb();
		
		bulbSwith.switchOn();
		
		Thread.sleep(5000);
		
		bulbSwith.switchOff();
		
	}

}
