package com.org;


public class Bulb implements ISwitch {
	public void switchOn(){
		on();
	}
	
	public void switchOff(){
		off();
	}
	
	
	@Override
	public void on() {
		System.out.println("Bulb is turned on  it glows !!!!");
	}

	@Override
	public void off() {
		System.out.println("Bulb is turned off  it dims !!!!");
	}

	

}
