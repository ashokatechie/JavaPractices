package com.org;

public interface ISwitch {

		void on();
		
		void off();
}
