package com.day.three;

public interface IDrivable {
	
	static public final float pi = 22.7f;

	void drive();
	
	void stop();
	
}
