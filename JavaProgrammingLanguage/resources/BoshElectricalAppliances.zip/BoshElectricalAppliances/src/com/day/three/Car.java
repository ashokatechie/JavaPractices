package com.day.three;

public abstract class Car {

	public abstract void drive();
	
	public void stop(){
		System.out.println("Car Stopped !!! ");
	}
	
}

