package com.org;

import java.util.Scanner;

public class HelloWorld {

	public static void main(String[] args) {
	
		Scanner scanner = new Scanner(System.in);		
		System.out.println("Enter the Farenheit");		
		Float farehn = scanner.nextFloat();
		
		
		Float temperatue = Float.valueOf(farehn);
		temperatue = (( temperatue - 32) * 5) / 9;
		

		System.out.println("Celcius for Farenheit ("+farehn+") is : " + temperatue);
		
		
		scanner.close();
		
	}

}


